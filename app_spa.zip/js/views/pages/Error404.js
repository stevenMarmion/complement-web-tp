// Instantiate API
export default class Error404 {
    async render () {
        let view =  `
            <h2>Error 404</h2>
        `;
        return view
    }
}