export default class About {
    async render () {
        return /*html*/`
            <section class="section">
                <h1>Information</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam, optio? Culpa ipsum facilis accusamus et iure cupiditate quae minima eum veritatis! Ipsum, hic nemo! Suscipit eligendi magnam atque fugit error.</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam, optio? Culpa ipsum facilis accusamus et iure cupiditate quae minima eum veritatis! Ipsum, hic nemo! Suscipit eligendi magnam atque fugit error.</p>
            </section>
            <p><a href="/">back to home</a></p>
        `
    }
}
